==============================================================================================================
	                                  Farmer's Market Stock Tracker		
==============================================================================================================

Thank you for installing the Farmer's Market Stock Tracker. This Readme file contains everything you need to get going.

== Minimum Sepcifications Needed ==

 * Windows 10 Home edition
 * Intel i5 8th gen / Ryzen 5 3600
 * 8gb RAM
 * 20gb Storage needed for Microsoft Visual Studio - (If you wish to run the program locally)

== Installation (If you wish to run the program locally) ==

 1) If you do not have Microsoft Visual Studio installed, please use the following link to download the 
    software: https://visualstudio.microsoft.com/vs/
 2) If you do have Microsoft Visual Studio installed, extract the FarmerMarketStockTracker folder from the zip folder.
 3) Paste the DTM_APPV3 folder in your local repository.
 4) Open Microsoft Visual Studio and select the FarmerMarketStockTracker folder from the main screen.

== How to Use ==
 
 1) Click on the project solution in the .zip folder.
 2) Visual Studio will now open, click the green start button at the top of the screen.
 3) On launch, the web interface will greet you with a welcome screen.
 4) You will then be able to view the Home, About and Author Information Pages respectfully.
 5) Depending on the type of role you have been allocated, you will only be able to view certain pages after
    the three mentioned above.
 5.1) Instructions for Farmer user:
      - If you are a farmer user, you have been granted access to the 'Products' page only. 
      - When you click on the 'Products' navigation option for the first time, you will be prompted to login.
      - Enter your designated email and password.
      - You will then be signed-in.
      - Click on the 'Add a new Product' button to load the form where you can input details on your product.
      - Enter the respective fields for your product and click enter.
      - Your user specific data will now be logged in the 'Products' page.
      - NOTE - you have create, read, update and delete privileges for this page ONLY. You cannot access the 'Farmer' and 'Search
        pages.
 5.2) Instructions to employee user:
      - If you are an employee user, you have been granted access to the 'Farmers' anb 'Search' pages.
      - When you click on the 'Farmers' navigation option, you will be directed to the 'List Of Farmers' Page, only after you have 
        logged in with your designated email and password.
      - Here you can add new farmers to the system.
      - To add a new farmer click 'Add Farmer.'
      - Enter all the fields related to farmer and click enter.
      - The new farmer was then entered.
      - To search for the product according to type, click the 'Search' navigation option.
      - Simply enter the product type, and then click filter.
      - You will then be able to view your search results.
      - NOTE - you onlu have create, read, update and delete privileges for the 'Farmers' page. You will be able to use the 'Search' page, however you
        cannot access the 'Products' page,
5.3) Intructions to admin user:
      - After logging in by clicking the option in the navigation bar, you will be able to view and write to all functions in the system, meaning you have read and 
        write privileges.
      - If you want to know more on how to enter values for each respective field, please read the instructions to the farmer and employee users above.

== Default Logins == 

 1) Admin User
    Email: admin@admin.com
    Password: Admin1234#
 
 2) Farmer one
    Email: jack@farmer.com
    Password: Farmer1234@

 3) Farmer two
    Email: nathan@farmer.com
    Password: Wheat321@

 4) Farmer three
    Email: geralt@farmer.com
    Password: Corn675$

 5) Employee User
    Email: employee@employee.com
    Password: Employee1234%

== Troubleshooting ==

   If you are having issues with getting the website to retrieve data please do the following:
   1) Open visual studio code.
   2) Click the search bar and type the following, "Package Manager Console."
   3) Select the Package Manager Console.
   4) In the console that appears, enter Add-migration InitialCreate, press enter.
   5) Then type Update-database and press enter.
   6) After a few seconds, the data will be populated for the website.
   7) Re-run the website to view the now populated data.
    
== FAQ's ==

 Q: Why do I need an account in order to use the system?
 A: There are three user roles, Farmer, Employee and Admin. The system needs to validate what type of user you are to authorize
    you into certain parts of the website

 Q: Why can I not access the farmer section as an employee?
    you do not have viewing access to this content that allows creation of products, however you can view all data in the search function.
 
 Q: Why am I not able to change my password?
 A: User passwords were designated, you do not have the permission to change them.

 Q: Am I the only person able to view my data?
 A: Yes, as all farmer users are only able to view THEIR own data and would never be able to access other farmer user data.

 Q: Can I access this web interface online?
 A: No, you can only access this web interface locally, for now.

== Plugins used ==

 1) Microsoft.AspNetCore.Diagnostics.EntityFrameworkCore - https://dotnet.microsoft.com/en-us/apps/aspnet
 2) Microsoft.AspNetCore.Identity.EntityFrameworkCore - https://dotnet.microsoft.com/en-us/apps/aspnet
 3) Microsoft.AspNetCore.Identity.UI - https://dotnet.microsoft.com/en-us/apps/aspnet
 4) Microsoft.EntityFrameworkCore.SqlServer - https://learn.microsoft.com/en-us/ef/core/
 5) Microsoft.EntityFrameworkCore.Tools - https://learn.microsoft.com/en-us/ef/core/
 6) Microsoft.VisualStudio.Web.CodeGeneration.Design - https://github.com/dotnet/Scaffolding

== GitHub Repository Link ==

 https://github.com/Brayt0n/PROG3A_Task-2.git

== Author Information ==

Author Name: Brayton 
Author Surname: Chetty
Business Address: 1 Link Road St James Avenue, Westvile, Durban, 3630

If you encounter any bugs while running the app please contact me on Outlook via my business email: ST10084590@vcconnect.edu.za

== Reference List ==

 1. Troelsen, A. Japikse, P. 2021. Pro C# with .Net 5. Apress Media, New York City.
 2. W3 Schools. 2023. How TO - Column Cards. [Online]. Available at: https://www.w3schools.com/howto/howto_css_column_cards.asp
    [Accessed 24 May 2023].
 3. MVC Role Management Intro - Part 1 - Authorization - .NET Core 6. YouTube video, added by I See Sharp. [Online]. Available at:
    https://www.youtube.com/watch?v=E8JaZdtXTBQ&t=46s [Accessed 25 May 2022].
 4. MVC Login and Registration with Identity - Identity Customization - .NET Core 6 - Part 1 - .NET Core 6. YouTube video, added by I See Sharp. [Online]. Available at:
    https://www.youtube.com/watch?v=E8JaZdtXTBQ&t=46s [Accessed 25 May 2022].
 5. CodePen. 2023. Navbar Animation. [Online]. Available at: https://codepen.io/jesusrmz/pen/OJMaVgV [Accessed 24 May 2023].
 6. CodePen. 2023. Some buttons. [Online]. Available at: https://codepen.io/cheeriottis/pen/AjmreP [Accessed 23 May 2023].
 7. CodePen. 2023. Music Carousal. [Online]. Avaialble at: https://codepen.io/louzhedong/pen/wRORJL [Accessed 25 May 2023].
 8. ASP.NET User Roles - Create and Assign Roles for AUTHORIZATION!. YouTube video, added by tutorialsEU - C#. [Online]. Avaialble at:
    https://www.youtube.com/watch?v=Y6DCP-yH-9Q&t=805s [Accessed 28 May 2023].
    