﻿using FarmersMarketStockTracker.Data;
using FarmersMarketStockTracker.Models;
using FarmersMarketStockTracker.ViewModels;
using FarmersMarketTracker.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace FarmersMarketStockTracker.Controllers
{
    [Authorize(Roles = "Employee, Admin")]
    public class FarmerListController : Controller
    {
        private readonly ApplicationDbContext _context;

        public FarmerListController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Products --> Index
        public async Task<IActionResult> List(string searchString)
        {
            var appDbContext = _context.Product.Where(f => f.productType == searchString);
            return View(await appDbContext.ToListAsync());
        }
    }
}
