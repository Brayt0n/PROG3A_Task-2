﻿using FarmersMarketTracker.Models;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FarmersMarketStockTracker.ViewModels
{
    public class ProductListModel
    {
        // get all the products
        public IEnumerable<Product> Products { get; set; }
    }
}
