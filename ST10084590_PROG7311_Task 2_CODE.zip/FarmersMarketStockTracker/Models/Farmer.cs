﻿using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FarmersMarketTracker.Models
{
    public class Farmer
    {
        // model that gets and sets information regarding each farmer user
        // variable to store farmer id
        public int farmerId { get; set; }
        // variable to store farmer first name
        public string farmerFname { get; set; }
        // variable to store farmer surname
        public string farmerSname { get; set; }
        // variable to store farmer email
        public string farmerEmail { get; set; }
        // variable to store farmer phone number
        public string farmerPhone { get; set; }
        // property list --> each farmer will have their own product
        public List<Product> Products { get; set; }
    }
}
