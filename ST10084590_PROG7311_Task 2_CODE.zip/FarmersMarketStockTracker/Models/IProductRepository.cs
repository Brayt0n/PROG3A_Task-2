﻿using System.Collections.Generic;

namespace FarmersMarketTracker.Models
{
    public interface IProductRepository
    {
        IEnumerable<Product> GetAllProducts { get; }

        //how --> Id
        Product GetProductById(int productId);
    }
}
