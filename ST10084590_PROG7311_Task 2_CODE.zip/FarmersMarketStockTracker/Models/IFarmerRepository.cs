﻿using FarmersMarketTracker.Models;
using System.Collections;
using System.Collections.Generic;

namespace FarmersMarketStockTracker.Models
{
    public interface IFarmerRepository
    {
        IEnumerable<Farmer> GetAllFarmers { get; }
    }
}
