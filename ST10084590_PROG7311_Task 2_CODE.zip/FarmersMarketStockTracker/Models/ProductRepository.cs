﻿using FarmersMarketStockTracker.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace FarmersMarketTracker.Models
{
    public class ProductRepository : IProductRepository
    {
        private readonly ApplicationDbContext _appDbContext;

        public ProductRepository(ApplicationDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<Product> GetAllProducts
        {
            get
            {
                return _appDbContext.Product.Include(s => s.Farmer); //gets all the variables from the categores class 

            }
        }

        public Product GetProductById(int productID)
        {
            return _appDbContext.Product.FirstOrDefault(s => s.productId == productID); //returns the first or default sweet ID. 
        }
    }
}
