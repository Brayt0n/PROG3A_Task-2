﻿using System;
using System.ComponentModel.DataAnnotations;

namespace FarmersMarketTracker.Models
{
    public class Product
    {
        // model to get and set values relating to product information
        // variable to store product id
        public int productId { get; set; }
        // variable to store product name
        public string productName { get; set; }
        // variable to store product type
        public string productType { get; set; }
        // variable to store product description
        public string productDescription { get; set; }
        // variable to store product price
        public decimal productPrice { get; set; }
        // variable to store the url to the image of the product
        public string imageUrl { get; set; }
        // variable to set product list date
        public DateTime productListDate { get; set; }
        // variable to store the farmer id
        public int farmerId { get; set; }
        // farmer class
        public Farmer Farmer { get; set; }
    }
}
