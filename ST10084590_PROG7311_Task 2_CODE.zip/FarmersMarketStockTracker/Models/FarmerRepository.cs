﻿using FarmersMarketStockTracker.Data;
using FarmersMarketTracker.Models;
using System;
using System.Collections;
using System.Collections.Generic;

namespace FarmersMarketStockTracker.Models
{
    public class FarmerRepository : IFarmerRepository
    {
        private readonly ApplicationDbContext _appDbContext;

        public FarmerRepository(ApplicationDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<Farmer> GetAllFarmers => _appDbContext.Farmer;
    }
}
