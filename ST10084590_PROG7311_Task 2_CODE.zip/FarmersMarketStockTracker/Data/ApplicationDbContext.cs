﻿using FarmersMarketStockTracker.Models;
using FarmersMarketTracker.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace FarmersMarketStockTracker.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // add db sets
        public DbSet<Product> Product { get; set; }

        // add db sets
        public DbSet<FarmersMarketTracker.Models.Farmer> Farmer { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            // seed demo data
            base.OnModelCreating(builder);

            // seed farmer
            builder.Entity<Farmer>().HasData(
                new Farmer { farmerId = 1, farmerFname = "Jack", farmerSname = "Ryan", farmerEmail = "jack@farmer.com", farmerPhone = "0659778891" },
                new Farmer { farmerId = 2, farmerFname = "Nathan", farmerSname = "Drake", farmerEmail = "nathan@farmer.com", farmerPhone = "0843827374" },
                new Farmer { farmerId = 3, farmerFname = "Geralt", farmerSname = "Of Rivia", farmerEmail = "geralt@farmer.com", farmerPhone = "0634572167" }
                );

            // seeded data for Jack
            builder.Entity<Product>().HasData(
                new Product
                {
                    productId = 1,
                    productName = "Apple",
                    productType = "Fruit",
                    productDescription = "Freshly grown red apple",
                    productListDate = DateTime.Now,
                    productPrice = 10,
                    imageUrl = "https://www.collinsdictionary.com/images/full/apple_158989157.jpg",
                    farmerId = 1
                }
                );

            builder.Entity<Product>().HasData(
                new Product
                {
                    productId = 2,
                    productName = "Banana",
                    productType = "Fruit",
                    productDescription = "High potassium nature product",
                    productListDate = DateTime.Now,
                    productPrice = 9,
                    imageUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Banana-Single.jpg/2324px-Banana-Single.jpg",
                    farmerId = 1
                }
                );

            builder.Entity<Product>().HasData(
                new Product
                {
                    productId = 3,
                    productName = "Pumpkin",
                    productType = "Vegetable",
                    productDescription = "Buttery pumpkin for sale",
                    productListDate = DateTime.Now,
                    productPrice = 6,
                    imageUrl = "https://images.immediate.co.uk/production/volatile/sites/30/2020/02/pumpkin-3f3d894.jpg?quality=90&resize=556,505",
                    farmerId = 1
                }
                );

            // seeded data for Nathan
            builder.Entity<Product>().HasData(
                new Product
                {
                    productId = 4,
                    productName = "Milk",
                    productType = "Dairy",
                    productDescription = "High calcium, quality milk",
                    productListDate = DateTime.Now,
                    productPrice = 20,
                    imageUrl = "https://images.immediate.co.uk/production/volatile/sites/30/2020/02/Glass-and-bottle-of-milk-fe0997a.jpg?resize=960,872",
                    farmerId = 2
                }
                );

            builder.Entity<Product>().HasData(
                new Product
                {
                    productId = 5,
                    productName = "Cheese",
                    productType = "Dairy",
                    productDescription = "Delicious cheddar cheese",
                    productListDate = DateTime.Now,
                    productPrice = 20,
                    imageUrl = "https://cdn.britannica.com/60/217660-050-DBCC409A/cheddar-cheese-wedge.jpg",
                    farmerId = 2
                }
                );

            builder.Entity<Product>().HasData(
                new Product
                {
                    productId = 6,
                    productName = "Butter",
                    productType = "Dairy",
                    productDescription = "Creamy butter for sale",
                    productListDate = DateTime.Now,
                    productPrice = 65,
                    imageUrl = "https://freshearth.co.za/wp-content/uploads/2020/04/butteeer.jpg",
                    farmerId = 2
                }
                );

            // seeded data for Geralt
            builder.Entity<Product>().HasData(
                new Product
                {
                    productId = 7,
                    productName = "Pear",
                    productType = "Fruit",
                    productDescription = "Delicious green pear",
                    productListDate = DateTime.Now,
                    productPrice = 20,
                    imageUrl = "https://img.freepik.com/free-vector/vintage-pear-illustration_53876-112720.jpg?w=2000",
                    farmerId = 3
                }
                );

            builder.Entity<Product>().HasData(
                new Product
                {
                    productId = 8,
                    productName = "Carrot",
                    productType = "Vegetable",
                    productDescription = "Taste carrots that will help you see better!",
                    productListDate = DateTime.Now,
                    productPrice = 12,
                    imageUrl = "https://grospace.co.za/wp-content/uploads/2021/03/GroSpace-Carrots.jpg",
                    farmerId = 3
                }
                );

            builder.Entity<Product>().HasData(
                new Product
                {
                    productId = 9,
                    productName = "Lettuce",
                    productType = "Vegetable",
                    productDescription = "Healthy, green lettuce",
                    productListDate = DateTime.Now,
                    productPrice = 20,
                    imageUrl = "https://cdn.britannica.com/77/170677-050-F7333D51/lettuce.jpg",
                    farmerId = 3
                }
                );
        }
    }
}
